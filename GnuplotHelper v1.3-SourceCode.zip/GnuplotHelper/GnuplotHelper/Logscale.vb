﻿'This file is part of Gnuplot Helper.

'    Gnuplot Helper is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.

'    Gnuplot Helper is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.

'    You should have received a copy of the GNU General Public License
'    along with Gnuplot Helper.  If not, see <https://www.gnu.org/licenses/>.

Public Class Logscale
    Dim buttonPressed As Boolean = False

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton2.Checked = True Then
            If Form1.LogCheck = "x" Then
                Form1.xBase = 10
                Form1.Label26.Text = "Base: 10"
                Form1.Label26.Visible = True
            End If
            If Form1.LogCheck = "y" Then
                Form1.yBase = 10
                Form1.Label28.Text = "Base: 10"
                Form1.Label28.Visible = True
            End If
            If Form1.LogCheck = "z" Then
                Form1.zBase = 10
                Form1.Label30.Text = "Base: 10"
                Form1.Label30.Visible = True
            End If
        Else
            If Form1.LogCheck = "x" Then
                Form1.xBase = 2.718281828459
                Form1.Label26.Text = "Base: e"
                Form1.Label26.Visible = True
            End If

            If Form1.LogCheck = "y" Then
                Form1.yBase = 2.718281828459
                Form1.Label28.Text = "Base: e"
                Form1.Label28.Visible = True
            End If

            If Form1.LogCheck = "z" Then
                Form1.zBase = 2.718281828459
                Form1.Label30.Text = "Base: e"
                Form1.Label30.Visible = True
            End If
        End If
        buttonPressed = True
        Me.Close()
    End Sub

    Private Sub Logscale_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Form1.Enabled = True
        ' Form1.CheckBox1.Checked = False
    End Sub

    Private Sub Logscale_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If buttonPressed = False Then
            If Form1.xBase = 0 Then Form1.CheckBox1.Checked = False
            If Form1.yBase = 0 Then Form1.CheckBox2.Checked = False
            If Form1.zBase = 0 Then Form1.CheckBox3.Checked = False
        End If
    End Sub

    Private Sub Logscale_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Form1.Enabled = False
        Me.TopMost = True
    End Sub
End Class