﻿Imports System.IO.Path
Imports System.IO

Public Class Form5



    Public fitfuction As String = ""
    Public fitparameters As String = ""
    Dim par(100) As String
    Dim eqn As String
    Dim filePath As String = Path.GetDirectoryName(Form1.fitPath) & "/fit.log"
    Private Sub Form5_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Form1.Enabled = True
        My.Settings.FitLog = CheckBox1.Checked
    End Sub

    Private Sub Form5_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
    
        If Form1.RadioButton12.Checked Then Label3.Text = "z(x,y)="
        'TextBox2.Text = "a,c"
        CheckBox1.Checked = My.Settings.FitLog
        If System.IO.File.Exists(filepath) Then
            System.IO.File.Delete(filepath)
        End If
        Me.TopMost = True
        'Form1.Enabled = False
        ToolTip1.SetToolTip(TextBox1, "Paramters --> a,b,c etc." & vbCrLf & "Variables --> x, y" & vbCrLf & "Functions --> exp(), log(), sin(), cos() etc." _
                            & vbCrLf & "Operators --> +(addition), -(subtraction), *(multiplication), /(division), **(exponent)")
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        'Try
        My.Settings.FitLog = CheckBox1.Checked
        If Not (TextBox1.Text = "") Then
            fitfuction = TextBox1.Text
            fitparameters = funcToPar(fitfuction) 'TextBox2.Text
            eqn = fitfuction
        Else
            MsgBox("Please fill the boxes above")
            Exit Sub
            'Me.Close()
        End If


        Me.Cursor = Cursors.WaitCursor

        Dim usng As String
        If Form1.RadioButton11.Checked = True Then
            usng = " using " & Form1.NumericUpDown3.Value & ":" & Form1.NumericUpDown4.Value
        Else
            usng = " using " & Form1.NumericUpDown3.Value & ":" & Form1.NumericUpDown4.Value & ":" & Form1.NumericUpDown7.Value
        End If
        Form1.fitWriter("fit " & fitfuction & " '" & Form1.TextBox7.Text & "' " & usng & " via " & fitparameters, False)
        Form1.batWriter("fitGnuplotHelper.plt", False)
        Dim i As Integer = 0
        For Each c As Char In fitparameters 'TextBox2.Text
            If Not (c = "," Or c = " ") Then

                par(i) = par(i) & c
            Else
                i += 1

            End If

        Next



        'Process.Start("cmd.exe", "C:/Users/Dwaipayan Deb/AppData/Roaming/GnuplotHelper/fitfunc.bat")
        Try
            Dim processinfo As New ProcessStartInfo()
            processinfo.WorkingDirectory = Path.GetDirectoryName(Form1.batPath)
            processinfo.FileName = Path.GetFileName(Form1.batPath)
            'processinfo.Arguments = " -persist " & Form1.plotPath
            Process.Start(processinfo)
            ' Process.Start(Form1.gnuplotPath, " -persist" & Form1.fitPath)
        Catch ex As Exception

            MessageBox.Show("Could not complete operation", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error, _
             MessageBoxDefaultButton.Button1, 0, "")

        End Try

        'RichTextBox1.Text = "Please Wait..."




        Dim TextLine As String
a:
        Application.DoEvents()
        If System.IO.File.Exists(filePath) = True Then
            For trial = 0 To 9
                Try
                    Dim objReader As New System.IO.StreamReader(filePath)
                    Dim line As String
                    Do While objReader.Peek() <> -1
                        line = objReader.ReadLine()
                        TextLine = TextLine & vbCrLf & line '& vbNewLine
                        If Len(line) > 18 Then
                            For Each item As String In par
                                If Not String.IsNullOrEmpty(item) Then
                                    If (line.Substring(0, Len(item)) = item And line.Substring(16, 1) = "=") Then
                                        Try
                                            eqn = replaceParameter(eqn, item, line.Substring(18, 27).Split()(0)) 'eqn.Replace(item, line.Substring(18, 27).Split()(0))
                                        Catch ex As Exception
                                            MsgBox("Could not produce any result!" & vbCrLf & "Try different equation.")
                                            If System.IO.File.Exists(filePath) Then Process.Start(filePath)
                                            GoTo b
                                        End Try
                                    End If
                                End If
                            Next
                        End If
                    Loop
                    Form1.Invoke(Sub() Form1.Button3.PerformClick())
                    System.Threading.Thread.Sleep(500)
                    Form1.TextBox8.Text = eqn
                    Form1.RadioButton2.Checked = True
                    System.Threading.Thread.Sleep(500)
                    Form1.Invoke(Sub() Form1.Button2.PerformClick())

                    'Button1.Text = "Close"

                    If CheckBox1.Checked Then Process.Start(filePath) 'RichTextBox1.Text = "Gnuplot log:" & vbCrLf & TextLine
b:
                    System.Threading.Thread.Sleep(3000)
                    objReader.Dispose()
                    If System.IO.File.Exists(filePath) Then
                        System.IO.File.Delete(filePath)
                    End If
                    GoTo c
                Catch ex As Exception
                    System.Threading.Thread.Sleep(500)
                End Try
            Next
            MsgBox("Some error has occured. Please try again.")
            Me.Cursor = Cursors.Default
            Me.Close()
c:
        Else
            System.Threading.Thread.Sleep(500)
            GoTo a

        End If
        Me.Cursor = Cursors.Default

        Me.Close()
        'Catch ex As Exception
        'MsgBox("An unknown error has occured. Please close the Fit window and try again." & vbCrLf & "Error message: " & ex.Message)
        'End Try

        'MsgBox(Form1.fitPath)
    End Sub

 

    Private Function replaceParameter(ByVal equation As String, ByVal parameter As String, ByVal value As Single)
        Dim lst As List(Of String) = New List(Of String)()
        Dim returnString
        lst.Add("x")
        lst.Add("y")
        lst.Add("log")
        lst.Add("cos")
        lst.Add("sin")
        lst.Add("tan")
        lst.Add("exp")
        lst.Add("sqrt")

        For Each item As String In lst
            equation = equation.Replace(item, "'" & CStr(lst.IndexOf(item)) & "'")
            ' MsgBox(item & " " & rs)
        Next
        equation = equation.Replace(parameter, value)

        For Each item As String In lst
            equation = equation.Replace("'" & CStr(lst.IndexOf(item)) & "'", item)
            ' MsgBox(item & " " & rs)
        Next
        Return equation

    End Function



    Private Function funcToPar(ByVal func As String)

        Dim lst As List(Of String) = New List(Of String)()
        Dim returnString
        lst.Add("x")
        lst.Add("y")
        lst.Add("log")
        lst.Add("cos")
        lst.Add("sin")
        lst.Add("tan")
        lst.Add("exp")
        lst.Add("sqrt")
        lst.Add("+")
        lst.Add("-")
        lst.Add("*")
        lst.Add("**")
        lst.Add("/")
        lst.Add("(")
        lst.Add(")")
        lst.Add(".")
        lst.Add(" ")
        For i = 0 To 9
            lst.Add(i)
        Next



        For Each item As String In lst
            func = func.Replace(item, ",")

        Next

        For i = 1 To Len(func)
            func = func.Replace(",,", ",")
        Next
        Dim b As String
        If func.Substring(Len(func) - 1, 1) = "," Then
            func = func.Remove(Len(func) - 1, 1)
        End If

        Return func
    End Function

    Private Sub TextBox1_Enter(sender As Object, e As System.EventArgs) Handles TextBox1.Enter

    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Invoke(Sub() Button1.PerformClick())
        End If
    End Sub

    
End Class