﻿
Public Class Form6
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Try  
            Process.Start("https://sourceforge.net/projects/gnuplot-helper/files/latest/download")
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
        Me.Close()
    End Sub
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox1.CheckedChanged
        My.Settings.AutoUpdate = CheckBox1.Checked
        'MsgBox(CheckBox1.Checked)
    End Sub

    Private Sub Form6_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.TopMost = True
    End Sub
End Class