For Users:
----------
This programs has been wriiten for free use without any commercial interest.
Therefore buying Certificate Key from providers has not been possible - due to which
Windows Smart Screen Filter may try to prevent installation mentioning me as untrusted source.
If you can trust me then you may start installation by clicking - 'More Info' and then 'Run Anyway' option
on the blue screen of Smart Screen Filter.
For any problem/bug you may start a discussion on sourceforge.
Important: If you do not get any output after pressing PLOT button, you may consider choosing png terminal instead of default. 

For Developers:
---------------
This program has been written in Visual Basic 2010.
It can be compiled on Visual Studio 2019 also(tested).
To view the code open the file 'GnuplotHelper.sln' with any version of Visual Studio (2010 onwards).
You can edit the code and distribute in compliance with GNU-GPL-v3.0 public license.
Please read carefully the GPL license terms which is attached in this program.
  
You can contanct me if you would like to be a member of this project on sourceforge.


-Dwaipayan Deb
Email: dwaipayandeb@yahoo.co.in
Website: www.respt.in