﻿'This file is part of Gnuplot Helper.

'    Gnuplot Helper is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.

'    Gnuplot Helper is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.

'    You should have received a copy of the GNU General Public License
'    along with Gnuplot Helper.  If not, see <https://www.gnu.org/licenses/>.

Imports System.IO
Public Class Form1
    Dim filepath As String =""
    Dim filename As String
    Dim plotString As String = ""
    Dim addString As String = ""
    Public xBase As Single = 0
    Public yBase As Single = 0
    Public zBase As Single = 0
    Public LogCheck As String

    Dim pD As String = "p"
    Dim docPath1 As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
    Dim docPath2 As String = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
    Dim docPath3 As String = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)
    Dim docPath As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments
    Dim appFilePath As String
    Dim appFilePath2 As String
    Dim gnuplotPath As String
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Form2.Show()
        If My.Settings.WelcomeMsg = True Then
            Form2.Show()
            My.Settings.WelcomeMsg = False
        End If
        'If My.Settings.GnuplotInstallCheck = True Then
        '    If Not System.IO.File.Exists(docPath2 & "\gnuplot\bin\gnuplot.exe") And Not System.IO.File.Exists(docPath3 & "\gnuplot\bin\gnuplot.exe") Then
        '        Form3.Show()
        '    End If
        'End If
        If System.IO.File.Exists(docPath2 & "\gnuplot\bin\gnuplot.exe") Then
            gnuplotPath = docPath2 & "\gnuplot\bin\gnuplot.exe"
        ElseIf System.IO.File.Exists(docPath3 & "\gnuplot\bin\gnuplot.exe") Then
            gnuplotPath = docPath3 & "\gnuplot\bin\gnuplot.exe"
        ElseIf System.IO.File.Exists("C:\Program Files\gnuplot\bin\gnuplot.exe") Then
            gnuplotPath = "C:\Program Files\gnuplot\bin\gnuplot.exe"
        ElseIf System.IO.File.Exists("C:\Program Files (x86)\gnuplot\bin\gnuplot.exe") Then
            gnuplotPath = "C:\Program Files (x86)\gnuplot\bin\gnuplot.exe"
        Else
            Form3.Show()
        End If

        If Not System.IO.Directory.Exists(docPath1 & "\GnuplotHelper") Then
            System.IO.Directory.CreateDirectory(docPath1 & "\GnuplotHelper")

        End If
        If Not System.IO.File.Exists(docPath1 & "\GnuplotHelper\GnuplotHelper.plt") Then
            System.IO.File.Create(docPath1 & "\GnuplotHelper\GnuplotHelper.plt").Close()
            appFilePath = docPath1 & "\GnuplotHelper\GnuplotHelper.plt"
        Else
            appFilePath = docPath1 & "\GnuplotHelper\GnuplotHelper.plt"
            FileWriter("", False)
        End If
        If Not System.IO.File.Exists(docPath1 & "\GnuplotHelper\MultiplotHelper.plt") Then
            System.IO.File.Create(docPath1 & "\GnuplotHelper\MultiplotHelper.plt").Close()
            appFilePath2 = docPath1 & "\GnuplotHelper\MultiplotHelper.plt"
        Else
            appFilePath2 = docPath1 & "\GnuplotHelper\MultiplotHelper.plt"
            multiplotSaver("", False)
        End If
        ' MsgBox(docPath1 & "\GnuplotHelper")


        ToolTip1.SetToolTip(TextBox8, "Please note that for 2D plot the varaible is only x" & vbCrLf & " and for 3D x and y both (always lower case)." & vbCrLf & " Arbitrary constants such as a,b,c etc. are not allowed." & vbCrLf & " Exponents or Powers may be represented by **." & vbCrLf & " Example for 2D: 5.36*(x**0.5)-3*x " & vbCrLf & " Example for 3D: x*(y**2)+5*x")
        ToolTip1.SetToolTip(TextBox24, "Please note that if data file separator is space(' ') " & vbCrLf & "then no need to fill this column. If you give" & vbCrLf & " a 'single space' in this box then exclusively 'single space'" & vbCrLf & " will be considered as data separator for all the columns." & vbCrLf & " Same for 'double space' or higher.")
        ToolTip1.SetToolTip(Label34, "Please note that for 2D plot the varaible is only x" & vbCrLf & " and for 3D x and y both (always lower case)." & vbCrLf & " Arbitrary constants such as a,b,c etc. are not allowed." & vbCrLf & " Exponents or Powers may be represented by **." & vbCrLf & " Example for 2D: 5.36*(x**0.5)-3*x " & vbCrLf & " Example for 3D: x*(y**2)+5*x")
        ToolTip1.SetToolTip(Label36, "Please note that if data file separator is space(' ') " & vbCrLf & "then no need to fill this column. If you give" & vbCrLf & " a 'single space' in this box then exclusively 'single space'" & vbCrLf & " will be considered as data separator for all the columns." & vbCrLf & " Same for 'double space' or higher.")


        GroupBox7.Enabled = False
        TextBox9.Select()
    End Sub


    Private Function FileWriter(ByVal myText As String, ByVal TrueFalse As Boolean)
        Dim objwriter As New System.IO.StreamWriter(appFilePath, TrueFalse) 'False for overwrite, True for append
        objwriter.WriteLine(myText)
        objwriter.Close()
    End Function
    Private Function multiplotSaver(ByVal myText As String, ByVal TrueFalse As Boolean)
        Dim objwriter As New System.IO.StreamWriter(appFilePath2, TrueFalse) 'False for overwrite, True for append
        objwriter.WriteLine(myText)
        objwriter.Close()
    End Function


    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
       
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
       
    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged
      
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        
    End Sub

    Private Sub TextBox7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.Click
        'TextBox7.Clear()
    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged
        If Not TextBox7.Text = "" Then
            'Label8.Enabled = False
            TextBox8.Clear()
            'TextBox9.Clear()
            'TextBox8.Enabled = False
            'Label9.Enabled = False
        Else
            'Label8.Enabled = True
            'TextBox8.Enabled = True
            'Label9.Enabled = True
        End If
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        If Not TextBox8.Text = "" Then
            'Label7.Enabled = False
            TextBox7.Clear()

            'TextBox7.Enabled = False
            'Label9.Enabled = False
            GroupBox5.Enabled = False
        Else
            'Label7.Enabled = True
            'TextBox7.Enabled = True
            'Label9.Enabled = True
            GroupBox5.Enabled = True
        End If
    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'OpenFileDialog1.ShowDialog()
        If (OpenFileDialog1.ShowDialog = DialogResult.OK) Then
            TextBox7.Text = OpenFileDialog1.FileName
        End If

        'MsgBox(OpenFileDialog1.FileName)
    End Sub





    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click

    End Sub

    Private Sub RadioButton12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton12.CheckedChanged




        If RadioButton12.Checked = True Then


            RadioButton1.Enabled = True
            RadioButton2.Enabled = True
            RadioButton3.Enabled = True
            RadioButton4.Enabled = True
            RadioButton5.Enabled = False
            RadioButton6.Enabled = False
            RadioButton7.Enabled = False
            RadioButton8.Enabled = True
            RadioButton9.Enabled = False
            RadioButton10.Enabled = False
            RadioButton15.Enabled = False
            RadioButton16.Enabled = False
            RadioButton13.Enabled = False
            RadioButton14.Enabled = False

            RadioButton8.Text = "Pm3d"

            Label34.Text = "z(x,y)="
            CheckBox4.Checked = False
            CheckBox4.Enabled = False
            GroupBox7.Enabled = True
            Label15.Enabled = False
            Label16.Enabled = False
            NumericUpDown5.ForeColor = Color.White
            NumericUpDown6.ForeColor = Color.White


            ' NumericUpDown5.BackColor = Color.Gray
        Else
            RadioButton1.Enabled = True
            RadioButton2.Enabled = True
            RadioButton3.Enabled = True
            RadioButton4.Enabled = True
            RadioButton5.Enabled = True
            RadioButton6.Enabled = True
            RadioButton7.Enabled = True
            RadioButton8.Enabled = True
            RadioButton9.Enabled = True
            RadioButton10.Enabled = True
            RadioButton15.Enabled = True
            RadioButton16.Enabled = True
            RadioButton13.Enabled = True
            RadioButton14.Enabled = True

            RadioButton8.Text = "Boxes"

            Label34.Text = "   y(x)="
            CheckBox4.Enabled = True
            GroupBox7.Enabled = False
            Label15.Enabled = True
            Label16.Enabled = True
            NumericUpDown5.ForeColor = Color.Black
            NumericUpDown6.ForeColor = Color.Black
        End If
    End Sub



    Private Sub RadioButton11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton11.CheckedChanged
        If RadioButton12.Checked = False Then
            Label17.Enabled = False
            TextBox23.Visible = False
            pD = "p"
            NumericUpDown7.ForeColor = Color.White
        Else
            Label17.Enabled = True
            TextBox23.Visible = True
            NumericUpDown7.ForeColor = Color.Black
            pD = "sp"
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            If TextBox2.Text = "" Or TextBox3.Text = "" Then
                MsgBox("Please set range first")
                CheckBox1.Checked = False
                Exit Sub
            End If
            If Not TextBox2.Text = "" Then
                If TextBox2.Text <= 0 Then
                    MsgBox("Minimum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox2.Clear()
                    CheckBox1.Checked = False
                    Exit Sub
                End If
            End If
            If Not TextBox3.Text = "" Then
                If TextBox3.Text <= 0 Then
                    MsgBox("Maximum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox3.Clear()
                    CheckBox1.Checked = False
                    Exit Sub
                End If
            End If


            LogCheck = "x"
            Logscale.Show()

        Else
            xBase = 0
            Label26.Visible = False
            Logscale.Close()
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            If TextBox5.Text = "" Or TextBox4.Text = "" Then
                MsgBox("Please set range first")
                CheckBox2.Checked = False
                Exit Sub
            End If
            If Not TextBox5.Text = "" Then
                If TextBox5.Text <= 0 Then
                    MsgBox("Minimum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox5.Clear()
                    CheckBox2.Checked = False
                    Exit Sub
                End If
            End If
            If Not TextBox4.Text = "" Then
                If TextBox4.Text <= 0 Then
                    MsgBox("Maximum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox4.Clear()
                    CheckBox2.Checked = False
                    Exit Sub
                End If
            End If
            LogCheck = "y"
            Logscale.Show()
        Else
            yBase = 0
            Label28.Visible = False
            Logscale.Close()
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            If TextBox14.Text = "" Or TextBox13.Text = "" Then
                MsgBox("Please set range first")
                CheckBox3.Checked = False
                Exit Sub
            End If
            If Not TextBox14.Text = "" Then
                If TextBox14.Text <= 0 Then
                    MsgBox("Minimum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox14.Clear()
                    CheckBox3.Checked = False
                    Exit Sub
                End If
            End If
            If Not TextBox13.Text = "" Then
                If TextBox13.Text <= 0 Then
                    MsgBox("Maximum of range can not be less than or equal to zero for logarithmic scale.")
                    TextBox13.Clear()
                    CheckBox3.Checked = False
                    Exit Sub
                End If
            End If
            LogCheck = "z"
            Logscale.Show()
        Else
            zBase = 0
            Label30.Visible = False
            Logscale.Close()
        End If
    End Sub


    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged
        If Not IsNumeric(TextBox10.Text) = True And Not TextBox10.Text = "" Then
            MsgBox("Tick can be Numbers Only")
            TextBox10.Clear()
        End If

    End Sub

    Private Sub TextBox14_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox14.TextChanged
        
    End Sub

    Private Sub TextBox13_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox13.TextChanged
       
    End Sub

    Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox11.TextChanged
        If Not IsNumeric(TextBox11.Text) = True And Not TextBox11.Text = "" Then
            MsgBox("Tick can be Numbers Only")
            TextBox11.Clear()
        End If
    End Sub

    Private Sub TextBox12_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox12.TextChanged
        If Not IsNumeric(TextBox12.Text) = True And Not TextBox12.Text = "" Then
            MsgBox("Tick can be Numbers Only")
            TextBox12.Clear()
        End If
    End Sub

    Private Sub TextBox17_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox17.TextChanged
        If Not IsNumeric(TextBox17.Text) = True And Not TextBox17.Text = "" Then
            MsgBox("Numbers Only")
            TextBox17.Clear()
        End If
    End Sub

    Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox16.TextChanged
        If Not IsNumeric(TextBox16.Text) = True And Not TextBox16.Text = "" Then
            MsgBox("Numbers Only")
            TextBox16.Clear()
        End If
    End Sub

    Private Sub TextBox19_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox19.TextChanged
        If Not IsNumeric(TextBox19.Text) = True And Not TextBox19.Text = "" Then
            MsgBox("Numbers Only")
            TextBox19.Clear()
        End If
    End Sub

    Private Sub TextBox18_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox18.TextChanged
        If Not IsNumeric(TextBox18.Text) = True And Not TextBox18.Text = "" Then
            MsgBox("Numbers Only")
            TextBox18.Clear()
        End If
    End Sub


    Private Sub TextBox2_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.Validated
        'Dim xmin As Single = CType(TextBox2.Text, Single)
        If Not IsNumeric(TextBox2.Text) = True And Not TextBox2.Text = "" Then
            MsgBox("Minimum of X-Range can be Numbers Only")
            TextBox2.Clear()
            TextBox2.Select()
        End If
        If IsNumeric(TextBox2.Text) = True Then TextBox21.Text = TextBox2.Text

        Try
            If CheckBox1.Checked = True Then
                If TextBox2.Text = "" Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox2.Select()
                End If
                If TextBox2.Text = 0 Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox2.Clear()
                    TextBox2.Select()
                End If

            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub TextBox10_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox10.Validated
        Try
            If TextBox10.Text = 0 Then
                MsgBox("Tick interval can not be zero." & vbCrLf & "Leave it blank if unsure")
                TextBox10.Clear()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox3_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox3.Validated
        If Not IsNumeric(TextBox3.Text) = True And Not TextBox3.Text = "" Then
            MsgBox("Maximum of X-Range can be Numbers Only")
            TextBox3.Clear()
            TextBox3.Select()
        End If
        Try
            If CheckBox1.Checked = True Then
                If TextBox3.Text = "" Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox3.Select()
                End If
                If TextBox3.Text = 0 Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox3.Clear()
                    TextBox3.Select()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox5_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.Validated
        If Not IsNumeric(TextBox5.Text) = True And Not TextBox5.Text = "" Then
            MsgBox("Minimum of Y-Range can be Numbers Only")
            TextBox5.Clear()
            TextBox5.Select()
        End If
        If IsNumeric(TextBox5.Text) = True Then TextBox22.Text = TextBox5.Text

        Try
            If CheckBox2.Checked = True Then
                If TextBox5.Text = "" Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox5.Select()
                End If
                If TextBox5.Text = 0 Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox5.Clear()
                    TextBox5.Select()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox4_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox4.Validated
        If Not IsNumeric(TextBox4.Text) = True And Not TextBox4.Text = "" Then
            MsgBox("Maximum of Y-Range can be Numbers Only")
            TextBox4.Clear()
            TextBox4.Select()
        End If

        Try
            If CheckBox2.Checked = True Then
                If TextBox4.Text = "" Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox4.Select()
                End If
                If TextBox4.Text = 0 Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox4.Clear()
                    TextBox4.Select()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox11_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox11.Validated
        Try
            If TextBox11.Text = 0 Then
                MsgBox("Tick interval can not be zero." & vbCrLf & "Leave it blank if unsure")
                TextBox11.Clear()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox14_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox14.Validated
        If Not IsNumeric(TextBox14.Text) = True And Not TextBox14.Text = "" Then
            MsgBox("Minimum of Z-Range can be Numbers Only")
            TextBox14.Clear()
            TextBox14.Select()
        End If
        If IsNumeric(TextBox14.Text) = True Then TextBox23.Text = TextBox14.Text

        Try
            If CheckBox3.Checked = True Then
                If TextBox14.Text = "" Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox14.Select()
                End If
                If TextBox14.Text = 0 Then
                    MsgBox("Minimum of range can not be zero or blank for logarithmic scale.")
                    TextBox14.Clear()
                    TextBox14.Select()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox13_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox13.Validated
        If Not IsNumeric(TextBox13.Text) = True And Not TextBox13.Text = "" Then
            MsgBox("Maximum of Z-Range can be Numbers Only")
            TextBox13.Clear()
            TextBox13.Select()
        End If

        Try
            If CheckBox3.Checked = True Then
                If TextBox13.Text = "" Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox13.Select()
                End If
                If TextBox13.Text = 0 Then
                    MsgBox("Maximum of range can not be zero or blank for logarithmic scale.")
                    TextBox13.Clear()
                    TextBox13.Select()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox12_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox12.Validated
        Try
            If TextBox12.Text = 0 Then
                MsgBox("Tick interval can not be zero." & vbCrLf & "Leave it blank if unsure")
                TextBox12.Clear()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox23_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox23.TextChanged
       
    End Sub

    Private Sub TextBox22_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox22.TextChanged
       
    End Sub

    Private Sub TextBox21_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox21.TextChanged
        
    End Sub
    Private Sub RadioButton10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton10.CheckedChanged
        If RadioButton10.Checked = True Then
            Label15.Text = "Radius"
            Label16.Enabled = False
            NumericUpDown6.Enabled = False
        ElseIf RadioButton10.Checked = False Then
            Label15.Text = "X-Error"
            Label16.Enabled = True
            NumericUpDown6.Enabled = True
        End If
    End Sub

    Private Sub RadioButton9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton9.CheckedChanged
        If RadioButton9.Checked = True Then
            Label15.Enabled = False
            NumericUpDown5.Enabled = False
        ElseIf RadioButton9.Checked = False Then
            Label15.Enabled = True
            NumericUpDown5.Enabled = True
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        If TextBox16.Text = "" Or TextBox17.Text = "" Or TextBox18.Text = "" Or TextBox19.Text = "" Or TextBox21.Text = "" Or TextBox22.Text = "" Or TextBox23.Text = "" Then
            MsgBox("Canvas size or Text location co-ordinates can not have empty field(s)")
            Exit Sub
        End If
        If CheckBox1.Checked = True And TextBox21.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox21.Select()
            Exit Sub
        End If
        If CheckBox2.Checked = True And TextBox22.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox22.Select()
            Exit Sub
        End If
        If CheckBox3.Checked = True And TextBox23.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox23.Select()
        End If


        If CheckBox4.Checked = False Then
            FileWriter("", False)
            'GroupBox1.Enabled = False
            'GroupBox2.Enabled = False
            'GroupBox7.Enabled = False
            'GroupBox8.Enabled = False

            'If ListBox1.Items.Count = 0 Then
            'MsgBox("Please add a plot in the list")
            'Exit Sub
            'End If
            FinalPlot()
            'Process.Start(appFilePath)
            Try
                Process.Start(appFilePath)
            Catch
                Try
                    Process.Start(gnuplotPath, appFilePath)
                Catch ex As Exception
                    MessageBox.Show("Could not find Gnuplot.exe in the path. If you have already installed gnuplot please set PATH environment variable", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error, _
    MessageBoxDefaultButton.Button1, 0, "https://answers.microsoft.com/en-us/windows/forum/windows_10-other_settings/adding-path-variable/97300613-20cb-4d85-8d0e-cc9d3549ba23", "")
                End Try
                End Try
        Else
                If ListBox1.Items.Count = 0 Then
                    MsgBox("For multiplot you must Add in the list first")
                    Exit Sub
                End If

                ' Process.Start(appFilePath)
                Try
                    Process.Start(appFilePath)
            Catch
                    Try
                        Process.Start(gnuplotPath, appFilePath)
                    Catch ex As Exception
                    MessageBox.Show("Could not find Gnuplot.exe in the path. If you have already installed gnuplot please set PATH environment variable", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error, _
    MessageBoxDefaultButton.Button1, 0, "https://answers.microsoft.com/en-us/windows/forum/windows_10-other_settings/adding-path-variable/97300613-20cb-4d85-8d0e-cc9d3549ba23", "")
                End Try
                    End Try
        End If
        'MsgBox("xb" & xBase & " yb" & yBase & " zb" & zBase)
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'GroupBox1.Enabled = False
        ' GroupBox2.Enabled = False
        ' GroupBox7.Enabled = False
        ' GroupBox8.Enabled = False

        If TextBox16.Text = "" Or TextBox17.Text = "" Or TextBox18.Text = "" Or TextBox19.Text = "" Or TextBox21.Text = "" Or TextBox22.Text = "" Or TextBox23.Text = "" Then
            MsgBox("Canvas size or Text location co-ordinates can not have empty field(s)")
            Exit Sub
        End If
        If CheckBox1.Checked = True And TextBox21.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox21.Select()
            Exit Sub
        End If
        If CheckBox2.Checked = True And TextBox22.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox22.Select()
            Exit Sub
        End If
        If CheckBox3.Checked = True And TextBox23.Text <= 0 Then
            MsgBox("Text co-ordinate can not be less than or equal to zero for logsale")
            TextBox23.Select()
        End If

        If TextBox7.Text <> "" Then
            ListBox1.Items.Add("Polt-" & ListBox1.Items.Count + 1 & " Data: " & TextBox7.Text)
        ElseIf TextBox8.Text <> "" Then
            ListBox1.Items.Add("Polt-" & ListBox1.Items.Count + 1 & " Eqn: y(x)=" & TextBox8.Text)
        Else
            MsgBox("Please give data file or equation")
            Exit Sub
        End If

        CheckBox4.Enabled = False

        If CheckBox4.Checked = False Then
            Plot()
            addString = plotString & ", " & addString
        Else
            If ListBox1.Items.Count = 1 Then
                FileWriter("", False)
                FileWriter("set multiplot", True)
            End If
            FinalPlot()
        End If
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
    End Sub


    Private Sub Plot()
        Dim title As String = " title '" & TextBox9.Text & "'"
        Dim usng As String
        Dim styl As String
        Dim typ As String
        If RadioButton1.Checked = True Then styl = "points"
        If RadioButton2.Checked = True Then styl = "lines"
        If RadioButton3.Checked = True Then styl = "linespoint"
        If RadioButton4.Checked = True Then styl = "dots"
        If RadioButton5.Checked = True Then styl = "xerrorbars"
        If RadioButton6.Checked = True Then styl = "yerrorbars"
        If RadioButton7.Checked = True Then styl = "xyerrorlines"
        If RadioButton12.Checked = True Then
            If RadioButton8.Checked = True Then styl = "pm3d"
        Else
            If RadioButton8.Checked = True Then styl = "boxes"
        End If
        If RadioButton9.Checked = True Then styl = "boxerrorbars"
        If RadioButton10.Checked = True Then styl = "circles"
        If RadioButton15.Checked = True Then styl = "yerrorlines"
        If RadioButton16.Checked = True Then styl = "xerrorlines"
        If RadioButton13.Checked = True Then styl = "impulses"
        If RadioButton14.Checked = True Then styl = "xyerrorbars"

        If RadioButton11.Checked = True Then
            If RadioButton5.Checked = True Or RadioButton16.Checked = True Or RadioButton9.Checked = True Or RadioButton10.Checked = True Then
                usng = " using " & NumericUpDown3.Value & ":" & NumericUpDown4.Value & ":" & NumericUpDown5.Value
            ElseIf RadioButton6.Checked = True Or RadioButton15.Checked = True Then
                usng = " using " & NumericUpDown3.Value & ":" & NumericUpDown4.Value & ":" & NumericUpDown6.Value
            ElseIf RadioButton14.Checked = True Or RadioButton7.Checked = True Then
                usng = " using " & NumericUpDown3.Value & ":" & NumericUpDown4.Value & ":" & NumericUpDown5.Value & ":" & NumericUpDown6.Value
            Else
                usng = " using " & NumericUpDown3.Value & ":" & NumericUpDown4.Value
            End If

        Else
            usng = " using " & NumericUpDown3.Value & ":" & NumericUpDown4.Value & ":" & NumericUpDown7.Value
        End If

        If TextBox9.Text = "" Then title = ""
        If TextBox7.Text = "" And TextBox8.Text = "" Then
            'MsgBox("Please give data file or equation")
            'Exit Sub
        End If
        typ = " ps " & NumericUpDown1.Value & " lw " & NumericUpDown9.Value & " pt " & NumericUpDown2.Value & " lt " & NumericUpDown8.Value
        If Not TextBox7.Text = "" Then
            plotString = " '" & TextBox7.Text & "' " & usng & title & " with " & styl & typ
            ' FileWriter(pD & plotString, True)
        ElseIf Not TextBox8.Text = "" Then
            plotString = " " & TextBox8.Text & title & " with " & styl & typ
            ' FileWriter(pD & plotString, True)
        Else
            plotString = ""
        End If
        ' MsgBox(plotString)
    End Sub
    Private Sub FinalPlot()
        ' If CheckBox4.Checked = True Then FileWriter("set multiplot", True)
        FileWriter("set size " & TextBox17.Text & "," & TextBox16.Text, True)
        FileWriter("set origin " & TextBox19.Text & "," & TextBox18.Text, True)
        If Not TextBox1.Text = "" Then FileWriter("set xlabel '" & TextBox1.Text & "'", True)
        If Not TextBox6.Text = "" Then FileWriter("set ylabel '" & TextBox6.Text & "'", True)
        If Not TextBox24.Text = "" Then FileWriter("set datafile separator '" & TextBox24.Text & "'", True)
        FileWriter("set xrange [" & TextBox2.Text & ":" & TextBox3.Text & "]", True)
        FileWriter("set yrange [" & TextBox5.Text & ":" & TextBox4.Text & "]", True)
        FileWriter("set xtics " & TextBox10.Text, True)
        FileWriter("set ytics " & TextBox11.Text, True)
        If RadioButton12.Checked = True Then
            If Not TextBox15.Text = "" Then FileWriter("set zlabel '" & TextBox15.Text & "'", True)
            FileWriter("set zrange [" & TextBox14.Text & ":" & TextBox13.Text & "]", True)
            FileWriter("set ztics " & TextBox12.Text, True)
        End If
        If CheckBox5.Checked = True Then FileWriter("set key box", True)
        If CheckBox6.Checked = True Then FileWriter("unset key", True)

        If RadioButton11.Checked = True Then
            FileWriter("set label '" & TextBox20.Text & "' at " & TextBox21.Text & "," & TextBox22.Text, True)
        Else
            FileWriter("set label '" & TextBox20.Text & "' at " & TextBox21.Text & "," & TextBox22.Text & "," & TextBox23.Text, True)
        End If

        Plot()
        If xBase <> 0 Then FileWriter("set logscale x " & xBase, True)
        If yBase <> 0 Then FileWriter("set logscale y " & yBase, True)
        If zBase <> 0 Then FileWriter("set logscale z " & zBase, True)
        If TextBox7.Text = "" And TextBox8.Text = "" Then
            FileWriter(pD & addString, True)
        Else
            FileWriter(pD & plotString & "," & addString, True)
        End If


        FileWriter("replot", True)
    End Sub








    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ListBox1.Items.Count = 0 Then
            MsgBox("Please Add in the list first")
            Exit Sub
        End If

        If CheckBox4.Checked = False Then
            Dim result As DialogResult = SaveFileDialog1.ShowDialog()
            'MsgBox(Path.GetExtension(SaveFileDialog1.FileName))
            If Not result = DialogResult.Cancel Then
                filepath = Path.GetFullPath(SaveFileDialog1.FileName)
                If Path.GetExtension(SaveFileDialog1.FileName) = ".ps" Then
                    FileWriter("set terminal postscript", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".eps" Then
                    FileWriter("set terminal postscript enhanced eps", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".jpeg" Then
                    FileWriter("set terminal jpeg", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".png" Then
                    FileWriter("set terminal png", True)
                End If
                FileWriter("set out '" & filepath & "'", True)
                FileWriter("replot", True)
                'Process.Start(appFilePath)
                Try
                    Process.Start(appFilePath)
                Catch
                    Try
                        Process.Start(gnuplotPath, appFilePath)
                    Catch ex As Exception
                       MessageBox.Show("Could not find Gnuplot.exe in the path. If you have already installed gnuplot please set PATH environment variable", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error, _
     MessageBoxDefaultButton.Button1, 0, "https://answers.microsoft.com/en-us/windows/forum/windows_10-other_settings/adding-path-variable/97300613-20cb-4d85-8d0e-cc9d3549ba23", "")
                    End Try
                    End Try
            End If
        Else
            Dim result As DialogResult = SaveFileDialog1.ShowDialog()
            'MsgBox(Path.GetExtension(SaveFileDialog1.FileName))
            If Not result = DialogResult.Cancel Then
                filepath = Path.GetFullPath(SaveFileDialog1.FileName)
                If Path.GetExtension(SaveFileDialog1.FileName) = ".ps" Then
                    multiplotSaver("set terminal postscript", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".eps" Then
                    multiplotSaver("set terminal postscript enhanced eps", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".jpeg" Then
                    multiplotSaver("set terminal jpeg", True)
                ElseIf Path.GetExtension(SaveFileDialog1.FileName) = ".png" Then
                    multiplotSaver("set terminal png", True)
                End If
                multiplotSaver("set out '" & filepath & "'", True)

                Dim s As String = IO.File.ReadAllText(appFilePath)
                IO.File.AppendAllText(appFilePath2, s)
                ' Process.Start(appFilePath2)
                Try
                    Process.Start(appFilePath2)
                Catch
                    Try
                        Process.Start(gnuplotPath, appFilePath2)
                    Catch ex As Exception
                       MessageBox.Show("Could not find Gnuplot.exe in the path. If you have already installed gnuplot please set PATH environment variable", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error, _
     MessageBoxDefaultButton.Button1, 0, "https://answers.microsoft.com/en-us/windows/forum/windows_10-other_settings/adding-path-variable/97300613-20cb-4d85-8d0e-cc9d3549ba23", "")
                    End Try
                    End Try
            End If
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True And My.Settings.MultiplotMsg = True Then
            Dim r As DialogResult = MessageBox.Show("Note that if you do not adjust the canvas size and origin for each plot separately" _
& " (according to your need) before adding in the list then the plots will overlap with eachother and you may not get desired result" & vbCrLf & vbCrLf & "Would you like to see this message again?", "WARNING!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, _
    MessageBoxDefaultButton.Button1, 0, "http://gnuplot.sourceforge.net/docs_4.2/node203.html", "")
            If r = DialogResult.No Then My.Settings.MultiplotMsg = False
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ListBox1.Items.Clear()
        plotString = ""
        addString = ""
        FileWriter("", False)
        multiplotSaver("", False)
        CheckBox4.Checked = False
        CheckBox4.Enabled = True
        My.Settings.MultiplotMsg = True
        TextBox16.Text = 1
        TextBox17.Text = 1
        TextBox18.Text = 0
        TextBox19.Text = 0
        TextBox20.Text = ""
        If Not TextBox2.Text = "" Then
            TextBox21.Text = TextBox2.Text
        Else
            TextBox21.Text = 0
        End If
        If Not TextBox5.Text = "" Then
            TextBox22.Text = TextBox5.Text
        Else
            TextBox22.Text = 0
        End If
        If Not TextBox14.Text = "" Then
            TextBox23.Text = TextBox14.Text
        Else
            TextBox23.Text = 0
        End If
        ' MsgBox(s)
    End Sub

    Private Sub Label25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label25.Click
        AboutBox1.Show()
        '   MessageBox.Show("  Gnuplot Helper v1.0" & vbCrLf & vbCrLf & "www.respt.in/p/projects" & vbCrLf & vbCrLf & "Copyright " & Chr(169) & " 2020 Dwaipayan Deb" & vbCrLf & vbCrLf & "Under GNU GPL v3 license", "About!", MessageBoxButtons.OK, MessageBoxIcon.Information, _
        'MessageBoxDefaultButton.Button1, 0, "https://www.respt.in/p/projects.html", "keyword (for google only)")
    End Sub
    Private Sub OvalShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.Click
        'MessageBox.Show("www.google.com", "About")
        AboutBox1.Show()
        '  MessageBox.Show("  Gnuplot Helper v1.0" & vbCrLf & vbCrLf & "www.respt.in/p/projects" & vbCrLf & vbCrLf & "Copyright " & Chr(169) & " 2020 Dwaipayan Deb" & vbCrLf & vbCrLf & "Under GNU GPL v3 license", "About!", MessageBoxButtons.OK, MessageBoxIcon.Information, _
        'MessageBoxDefaultButton.Button1, 0, "https://www.respt.in/p/projects.html", "keyword (for google only)")
        'Messageboxadv.
    End Sub

    Private Sub TextBox21_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox21.Validated
        If Not IsNumeric(TextBox21.Text) = True And Not TextBox21.Text = "" Then
            MsgBox("Numbers Only")
            TextBox21.Clear()
            TextBox21.Select()
        End If
    End Sub

    Private Sub TextBox22_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox22.Validated
        If Not IsNumeric(TextBox22.Text) = True And Not TextBox22.Text = "" Then
            MsgBox("Numbers Only")
            TextBox22.Clear()
            TextBox22.Select()
        End If
    End Sub

    Private Sub TextBox23_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox23.Validated
        If Not IsNumeric(TextBox23.Text) = True And Not TextBox23.Text = "" Then
            MsgBox("Numbers Only")
            TextBox23.Clear()
            TextBox23.Select()
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        'Process.Start("Notepad.exe", appFilePath)
        Try
            Process.Start("Notepad.exe", appFilePath)
        Catch
           
        End Try
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            TextBox9.Clear()
            TextBox9.Enabled = False
        Else
            TextBox9.Enabled = True
        End If
    End Sub
End Class
